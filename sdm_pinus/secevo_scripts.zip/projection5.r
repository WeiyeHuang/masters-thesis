# Load packages
library(terra, lib.loc = "/public4/group_wxk/home/wuxk/apps/envs/R/lib/R/library")
library(biomod2, lib.loc = "/public4/group_wxk/home/wuxk/apps/envs/R/lib/R/library")
library(ggplot2, lib.loc = "/public4/group_wxk/home/wuxk/apps/envs/R/lib/R/library")
library(dplyr, lib.loc = "/public4/group_wxk/home/wuxk/apps/envs/R/lib/R/library")

sessionInfo()

load('./RData/ensemble_model.RData')

# Paleodistribution modeling
# Design a function for multiple calls
paleodistribution_modeling <- function(time4modeling){
  paleo_clim <- rast(list.files(paste0("/public4/group_wxk/home/wuxk/public_data/climate/bristol_teyf/", time4modeling, "Ma"), pattern = 'asc$', full.names = T))
  
  names(paleo_clim) <- c('Bio1', 'Bio2', 'Bio3', 'Bio4', 'Bio5', 'Bio6', 'Bio7', 'Bio8',
                         'Bio9', 'Bio10', 'Bio11', 'Bio12', 'Bio13', 'Bio14', 'Bio15',
                         'Bio16', 'Bio17', 'Bio18', 'Bio19')
  
  paleo_clim <- paleo_clim[[top10_clim]]
  
  proj_paleo_single <- BIOMOD_Projection(
    bm.mod = model_for_projection,
    proj.name = paste0(time4modeling, "_", as.character(format(Sys.time(), "%s"))),
    new.env = paleo_clim,
    models.chosen = "all",
    output.format = ".tif",
    seed.val = 123,
    do.stack = F,
    nb.cpu = 1
  )
  proj_paleo_single
  
  proj_paleo_ensemble <- BIOMOD_EnsembleForecasting(
    bm.em = ensemble_model,
    bm.proj = proj_paleo_single,
    models.chosen = "all",
    output.format = ".tif",
    nb.cpu = 1
  )
  proj_paleo_ensemble
  
  ensproj_roc <- rast(paste0("./Models/",
                         "pinus",
                         "/proj_", proj_paleo_ensemble@proj.name,
                         "/individual_projections",
                         "/pinus_EMwmeanByROC_mergedData_mergedRun_mergedAlgo.tif"))
  ensproj_roc <- ensproj_roc / 1000 

  ensproj_tss <- rast(paste0("./Models/",
                         "pinus",
                         "/proj_", proj_paleo_ensemble@proj.name,
                         "/individual_projections",
                         "/pinus_EMwmeanByTSS_mergedData_mergedRun_mergedAlgo.tif"))
  ensproj_tss <- ensproj_tss / 1000 
  
  dir.create(paste0("./Projection/", proj_paleo_ensemble@proj.name))
  save_dir <- paste0("./Projection/", proj_paleo_ensemble@proj.name, "/")
  
  writeRaster(ensproj_roc, filename = paste0(save_dir, "ensproj_roc.tif"))
  writeRaster(ensproj_tss, filename = paste0(save_dir, "ensproj_tss.tif"))
  
  pdf(paste0(save_dir, 'plot.pdf'), 12, 7)
  plot(ensproj_roc)
  plot(ensproj_tss)
  dev.off()
  
  save.image(paste0(save_dir, time4modeling, '.RData'))

  gc()
}

# List the geological time for paleodistribution modeling
timelist <- c("80", "86", "91", "97")

# Use a loop to simulate one by one
for (i in 1:length(timelist)) {
  paleodistribution_modeling(timelist[i])
}
